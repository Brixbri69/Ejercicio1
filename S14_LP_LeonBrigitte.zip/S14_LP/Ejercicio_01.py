def menu():
    print("\nMENU:")
    print("1. INSERTAR")
    print("2. MODIFICAR")
    print("3. ELIMINAR")
    print("4. BUSCAR")
    print("5. MENOR")
    print("6. MAYOR")
    print("7. SALIR")

def main():
    lista = []

    while True:
        menu()
        opcion = input("Selecciona una opción: ")

        if opcion == "1":
            numero = int(input("Ingrese un número: "))
            lista.append(numero)
        elif opcion == "2":
            indice = int(input("Ingrese el índice a modificar: "))
            if 0 <= indice < len(lista):
                nuevo_valor = int(input("Nuevo valor: "))
                lista[indice] = nuevo_valor
            else:
                print("Índice fuera de rango.")
        elif opcion == "3":
            numero = int(input("Número a eliminar: "))
            if numero in lista:
                lista.remove(numero)
            else:
                print("Número no encontrado.")
        elif opcion == "4":
            numero = int(input("Número a buscar: "))
            if numero in lista:
                print(f"El número {numero} está en la lista.")
            else:
                print("Número no encontrado.")
        elif opcion == "5":
            if lista:
                print(f"El menor número es: {min(lista)}")
            else:
                print("La lista está vacía.")
        elif opcion == "6":
            if lista:
                print(f"El mayor número es: {max(lista)}")
            else:
                print("La lista está vacía.")
        elif opcion == "7":
            break
        else:
            print("Opción no válida.")

if __name__ == "__main__":
    main()
