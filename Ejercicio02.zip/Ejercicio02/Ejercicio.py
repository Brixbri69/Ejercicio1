def menu():
    print("\nMENU:")
    print("1. INSERTAR")
    print("2. MODIFICAR")
    print("3. ELIMINAR")
    print("4. SALIR")

def insertar(dato, tipo):
    if tipo == "habilidad":
        dato["habilidades"].append(input("Ingrese una nueva habilidad: "))
    elif tipo == "interes":
        dato["intereses"].append(input("Ingrese un nuevo interés: "))
    elif tipo == "documento":
        dato["documentos"].append(input("Ingrese el nombre del documento: "))

def modificar(dato, tipo):
    if tipo == "habilidad":
        print("Habilidades actuales:", dato["habilidades"])
        indice = int(input("Seleccione el índice de la habilidad a modificar: "))
        if 0 <= indice < len(dato["habilidades"]):
            nueva_habilidad = input("Ingrese la nueva habilidad: ")
            dato["habilidades"][indice] = nueva_habilidad
        else:
            print("Índice fuera de rango.")
    elif tipo == "interes":
        print("Intereses actuales:", dato["intereses"])
        indice = int(input("Seleccione el índice del interés a modificar: "))
        if 0 <= indice < len(dato["intereses"]):
            nuevo_interes = input("Ingrese el nuevo interés: ")
            dato["intereses"][indice] = nuevo_interes
        else:
            print("Índice fuera de rango.")
    elif tipo == "documento":
        print("Documentos actuales:", dato["documentos"])
        indice = int(input("Seleccione el índice del documento a modificar: "))
        if 0 <= indice < len(dato["documentos"]):
            nuevo_documento = input("Ingrese el nuevo nombre del documento: ")
            dato["documentos"][indice] = nuevo_documento
        else:
            print("Índice fuera de rango.")

def eliminar(dato, tipo):
    if tipo == "habilidad":
        print("Habilidades actuales:", dato["habilidades"])
        habilidad = input("Ingrese la habilidad a eliminar: ")
        if habilidad in dato["habilidades"]:
            dato["habilidades"].remove(habilidad)
            print(f"Habilidad '{habilidad}' eliminada.")
        else:
            print("Habilidad no encontrada.")
    elif tipo == "interes":
        print("Intereses actuales:", dato["intereses"])
        interes = input("Ingrese el interés a eliminar: ")
        if interes in dato["intereses"]:
            dato["intereses"].remove(interes)
            print(f"Interés '{interes}' eliminado.")
        else:
            print("Interés no encontrado.")
    elif tipo == "documento":
        print("Documentos actuales:", dato["documentos"])
        documento = input("Ingrese el documento a eliminar: ")
        if documento in dato["documentos"]:
            dato["documentos"].remove(documento)
            print(f"Documento '{documento}' eliminado.")
        else:
            print("Documento no encontrado.")

def main():
    persona = {
        "habilidades": [],
        "intereses": [],
        "documentos": []
    }

    while True:
        print("\nSeleccione la categoría que desea modificar:")
        print("1. HABILIDADES")
        print("2. INTERESES")
        print("3. DOCUMENTOS")
        print("4. VOLVER AL MENÚ PRINCIPAL")
        
        categoria = input("Seleccione una opción (1-4): ")

        if categoria == "1":
            menu()
            opcion = input("Seleccione una opción: ")
            if opcion == "1":
                insertar(persona, "habilidad")
            elif opcion == "2":
                modificar(persona, "habilidad")
            elif opcion == "3":
                eliminar(persona, "habilidad")
            elif opcion == "4":
                break
            else:
                print("Opción no válida.")
        
        elif categoria == "2":
            menu()
            opcion = input("Seleccione una opción: ")
            if opcion == "1":
                insertar(persona, "interes")
            elif opcion == "2":
                modificar(persona, "interes")
            elif opcion == "3":
                eliminar(persona, "interes")
            elif opcion == "4":
                break
            else:
                print("Opción no válida.")
        
        elif categoria == "3":
            menu()
            opcion = input("Seleccione una opción: ")
            if opcion == "1":
                insertar(persona, "documento")
            elif opcion == "2":
                modificar(persona, "documento")
            elif opcion == "3":
                eliminar(persona, "documento")
            elif opcion == "4":
                break
            else:
                print("Opción no válida.")
        
        elif categoria == "4":
            break
        
        else:
            print("Opción no válida.")

if __name__ == "__main__":
    main()
